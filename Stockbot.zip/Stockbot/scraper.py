import requests
import sys
from bs4 import BeautifulSoup
stockNameInput = sys.argv[1]
def scraperFunction(stockName):  
    URL = "https://www.benzinga.com/stock" + "/" + stockName + "/"
    page = requests.get(URL)
    soup = BeautifulSoup(page.content, 'html.parser')
    results = soup.find(id='benzinga-main')
    specificResults = soup.find(id='benzinga-main')

    currentValueResults = results.find_all('span',class_='price current-data')
    stockDeltaResults = results.find_all('span',class_='price change-data')
    rowStockAction = specificResults.find('div',class_='row stock-action')
    columnEightBenzinga = rowStockAction.find_all('span',class_='stock-data-value')


    currentStockValue = currentValueResults[0].text
    stockDelta = stockDeltaResults[0].text
    prevClosingValue = columnEightBenzinga[0].text
    openingValue = columnEightBenzinga[1].text

    print("The current value of " + stockName + " is " + currentStockValue)
    print("The previous closing value of " + stockName + " is " + prevClosingValue)
    print("Today's opening value of " + stockName + " is " + prevClosingValue)
    stockDeltaDecimal = stockDelta[slice(0,stockDelta.index("("))]
    stockDeltaPercent = stockDelta[slice(stockDelta.index("(")+1,stockDelta.index(")"))]
    stockIsDown = stockName + " is currently down " + stockDeltaDecimal + " points and is down by " + stockDeltaPercent
    stockIsUp = stockName + " is currently up " + stockDeltaDecimal + "points and is up by " + stockDeltaPercent
    if(stockDelta.find("-") != -1):
        print(stockIsDown)
    else:
        print(stockIsUp)

    sys.stdout.flush()
scraperFunction(stockNameInput)











