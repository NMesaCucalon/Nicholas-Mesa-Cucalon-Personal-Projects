const Discord = require('discord.js');
//Forces discord.js to be required to run this file, therefore connecting the discord.js dependency to this code
const bot = new Discord.Client();
//Creating the bot
const token = 'NzI0NTE5OTM0Mjc2NjY1MzY2.XvBYLQ.5LsKi8JCBHHTtqm05S5X6hz5jao'
//The token is the password to the bot; let's you log into the bot
const prefix = "$";
//The command symbol will be the $ sign


//Python scraper integration
function scraperCall(stockInput,username)
{
    const spawn = require('child_process').spawn;
    const process = spawn('python',['./scraper.py',stockInput]); 
    //Writing text files
    const fs = require('fs');
    var textPath = stockInput + username + ".txt";
    process.stdout.on('data', function(data){
        let textAnswer = data.toString();
        fs.writeFile(textPath,textAnswer,(err) => {
            if(err) throw err;
        });

    });
}


function autoNotifier(stockData,stockDelta)
{
    //Checks if the % delta from benzinga is in a certain threshold, returns a true or false value
    let percentageString = stockData.substring((stockData.indexOf("by")+2));
    let parsedInt = parseFloat(stringToIntFormatter(percentageString));
    if(parsedInt >= stockDelta)
        return true;
    return false;
}

function stringToIntFormatter(str)
{
    //Function that converts the benzinga string % number to a double that is easier to work with
    //Making a new function makes code more legible
    if(str.indexOf("-") != -1)
        str = str.substring(str.indexOf("-")+1);
    str = str.substring(0,str.indexOf("%"));
    return str;
}



bot.on('ready', () =>{
    console.log("The bot is running!");
    
    //Every 10 minutes it signals when a preset delta, so 5%, occurs
    
    var testChannel = bot.channels.cache.get('723775775186354206');
    
    var stockDeltaForWatchlist = 5.00
    
    
    var watchList = ['dis','amzn','baba','tmus','msft','cgc','tsla','aapl','sqnxf'];
    setInterval(() => {
        for(let i = 0; i < watchList.length; i++)
        {
            scraperCall(watchList[i],"Nico");
        }
        for(let i = 0; i < watchList.length; i++)
        {
            const fs = require('fs');
            var currentTextFilePath = watchList[i] + "Nico" + ".txt";
            fs.readFile(currentTextFilePath, function(err,buf) {
                if(err)
                {console.log(err);}
                //If delta is met, send msg, else do nothing
                if(autoNotifier(buf.toString(),stockDeltaForWatchlist))
                {
                    testChannel.send("This message is being sent because " + watchList[i] + " has changed by " + stockDeltaForWatchlist + "%");
                    testChannel.send("Check out the stock at https://www.benzinga.com/stock/" + watchList[i] + "/");
                }
                
            })
        }
        

    }, 900000);
    
    






})

bot.on('message',msg=>{
    let args = msg.content.substring(prefix.length).split(" ");
    switch(args[0])
    {
        //Clears chat with a command
        case 'clear':
            if(!args[1])
                return msg.reply("Pls give argument as to how many lines deleted")
            msg.channel.bulkDelete(args[1]);
            console.log("We're working");
            break;
        
        //My github
        case 'credits':
            msg.channel.send("https://github.com/NMesaCucalon");
            console.log("We're working");

            break;
        
        case 'stats':
            scraperCall(args[1],args[2]);
            var currentTextFilePath = args[1] + args[2] + ".txt";
            const fs = require('fs');
            fs.readFile(currentTextFilePath, function(err,buf) {
                if(err)
                {msg.channel.send("That's not the name of a stock, run the command again please!");}
                else
                    msg.channel.send(buf.toString());
            })
            console.log("We're working");

            break;
        case 'help':
            msg.channel.send("The available commands are clear, credits and stats.");
            msg.channel.send("Preface the message with the $ sign.");
            msg.channel.send("This bot will also check and notify every 10 minutes if a stock has changed by 5%");
            msg.channel.send("Stay tuned for more features!");
            console.log("We're working");

        }
    

        
    });
            



bot.login(token)
//Log's into the bot



