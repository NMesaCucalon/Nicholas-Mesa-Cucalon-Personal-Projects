Discord Stockbot
Nicholas Mesa-Cucalon
Table of Contents:
•	Introduction
•	Functions	
Introduction
This Stockbot, as it so affectionately called, was created by me for my friends in the Summer of 2020. My friends had recently begun getting into the stock market and were 
investing in Robinhood, so they all were excited about trading. They also played a lot of games at the time and did not do day trading or professional trading, so they just 
wanted occasional news and stock updates for when stocks they cared about changed. They tried using a bot that was already made for Discord, but it gave them data that they 
did not know how to use. I was talking to my friends at the time and as a result, I decided to try my hand at some JavaScript and make something useful for my friends that, 
if expanded upon, could become marketable. 

I spent about a week making a prototype of a discord bot that would use a Python web scraper to get data from Benzinga.com to display to my friends. Whenever a stock went up 
or down a certain threshold, namely 5%, it would automatically alert a channel in our Discord server of the news. It currently only has a hard-coded list of stocks, but in the
future, I intend to make it so each user of the Discord bot has a personal watchlist. It also allows them to type a stock name, so its data appears in the discord channel. 

Currently the bot has to be locally hosted when used, but it can be implemented on a server level eventually. It’s mainly useful, in its current state, for people who 
occasionally view the stock market and want to be updated on news about stocks without monitoring their news feed 24/7.

Functions
•	The prefix for all commands is a $ sign
•	$clear [# of lines]
o	This command is used to clear a channel of clutter that occurs when many users are using the Stockbot
o	It takes an integer input and clears that amount of lines in the channel
•	$stats [stock name] [username]
o	This command allows a user to see the current value of a stock, its previous closing value, its daily opening value and the amount of points and percentage it has changed by
o	It takes 2 string inputs, the stock name and the username. This currently generates a text file on the hosts computer, but this will be fixed in the future, so it is more sustainable. A JSON file will be used instead of a text file for each individual stock and user.
•	$help
o	Displays some information that the user can read to help them utilize the Stockbot or where to look for further assistance
o	Takes no inputs
